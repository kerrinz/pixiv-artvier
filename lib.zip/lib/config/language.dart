import 'dart:ui';

class LanguageConfig {
  static List<Locale> supportedLocales = const [
    Locale('zh', 'CN'),
    Locale('en', 'US'),
  ];
}
