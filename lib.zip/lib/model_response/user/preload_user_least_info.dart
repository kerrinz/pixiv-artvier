/*
  用户的最小信息，用于跳转新页面的预加载信息
* */

class PreloadUserLeastInfo extends Object {
  int id;

  String name;

  String avatar;

  PreloadUserLeastInfo(this.id,this.name,this.avatar,);

}
