// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: non_constant_identifier_names

part of 'bookmark_tag.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BookmarkTag _$BookmarkTagFromJson(Map<String, dynamic> json) => BookmarkTag()
  ..name = json['name'] as String?
  ..count = json['count'] as int?;

Map<String, dynamic> _$BookmarkTagToJson(BookmarkTag instance) =>
    <String, dynamic>{
      'name': instance.name,
      'count': instance.count,
    };
