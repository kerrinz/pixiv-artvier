import 'dart:io';

import 'package:dio/dio.dart';
import 'package:extended_nested_scroll_view/extended_nested_scroll_view.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pixgem/common_provider/illusts_provider.dart';
import 'package:pixgem/common_provider/loading_request_provider.dart';
import 'package:pixgem/common_provider/novels_provider.dart';
import 'package:pixgem/common_provider/works_provider.dart';
import 'package:pixgem/component/base_provider_widget.dart';
import 'package:pixgem/component/bottom_sheet/bottom_sheets.dart';
import 'package:pixgem/component/bottom_sheet/slide_bar.dart';
import 'package:pixgem/component/filter/stateless_flow_filter.dart';
import 'package:pixgem/component/loading/request_loading.dart';
import 'package:pixgem/config/constants.dart';
import 'package:pixgem/model_response/user/bookmark/bookmark_tag.dart';
import 'package:pixgem/pages/illust/tab_page/illusts_grid_tabpage.dart';
import 'package:pixgem/l10n/localization_intl.dart';
import 'package:pixgem/api_app/api_user.dart';
import 'package:pixgem/pages/novel/novel_list_tabpage.dart';
import 'package:pixgem/pages/user/bookmark/bookmark_tags_provider.dart';
import 'package:pixgem/routes.dart';
import 'package:provider/provider.dart';

class MyBookmarksPage extends StatefulWidget {
  late final String? userId;

  MyBookmarksPage(Object? arguments, {Key? key}) : super(key: key) {
    userId = arguments as String?;
  }

  @override
  State<StatefulWidget> createState() => _MyBookmarksState();
}

class _MyBookmarksState extends State<MyBookmarksPage> with TickerProviderStateMixin {
  late TabController _tabController;

  late ScrollController _scrollController;

  /// 插画列表数据管理
  final IllustListProvider illustsProvider = IllustListProvider();

  /// 小说列表数据管理
  final NovelListProvider novelsProvider = NovelListProvider();

  /// 标签的状态管理
  final BookmarkTagsProvider _tagsProvider = BookmarkTagsProvider();

  /// 插画（与漫画）的筛选条件
  final _FilterModel illustFilterModel = _FilterModel(CONSTANTS.restrict_public, null);

  /// 小说的筛选条件
  final _FilterModel novelFilterModel = _FilterModel(CONSTANTS.restrict_public, null);

  /// 列表请求所用
  CancelToken _cancelToken = CancelToken();

  /// 筛选条件获取Tag所用
  CancelToken _tagsCancelToken = CancelToken();

  /// 当前页面所处的作品类型
  WorksType get currentWorkType => _tabController.index == 0 ? WorksType.illust : WorksType.novel;

  /// 当前作品类型的FilterModel
  _FilterModel get currentFilterModel => currentWorkType == WorksType.illust ? illustFilterModel : novelFilterModel;

  /// 需要重新请求Tags数据（通过筛选弹窗切换了Filter，却取消了筛选，此时TagList不符合预期，于是下次弹窗需要重新请求标签列表）
  bool flagNeedReRequest = false;

  @override
  void initState() {
    super.initState();
    // 未登录拦截
    if (widget.userId == null) {
      Navigator.pushNamed(context, RouteNames.wizard.name);
    } else {
      _tabController = TabController(initialIndex: 0, length: 2, vsync: this);
      _tabController.addListener(() {
        _tagsProvider.setWorksType(currentWorkType);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    _scrollController = PrimaryScrollController.of(context) ?? ScrollController();
    return Scaffold(
      body: ExtendedNestedScrollView(
        floatHeaderSlivers: true,
        onlyOneScrollInBody: true,
        controller: _scrollController,
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          TabBar tabBar = TabBar(
            labelColor: Theme.of(context).colorScheme.onPrimary,
            indicatorColor: Theme.of(context).colorScheme.onPrimary,
            unselectedLabelColor: Theme.of(context).colorScheme.onPrimary.withAlpha(175),
            labelStyle: const TextStyle(fontSize: 14),
            unselectedLabelStyle: const TextStyle(fontSize: 13),
            labelPadding: const EdgeInsets.symmetric(horizontal: 13.0),
            indicatorSize: TabBarIndicatorSize.label,
            indicatorPadding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
            controller: _tabController,
            isScrollable: true,
            tabs: [
              Tab(
                child: Text("${LocalizationIntl.of(context).illustrations} • ${LocalizationIntl.of(context).manga}"),
              ),
              Tab(text: LocalizationIntl.of(context).novels),
            ],
          );
          return [
            SliverAppBar(
              pinned: true,
              floating: true,
              title: const Text('我的收藏'),
              backgroundColor: Theme.of(context).colorScheme.primary,
              bottom: PreferredSize(
                preferredSize: tabBar.preferredSize,
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: tabBar,
                    ),
                    // 筛选按钮
                    ProviderWidget<BookmarkTagsProvider>(
                      model: _tagsProvider,
                      builder: (buttonContext, provider, child) {
                        return CupertinoButton.filled(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          minSize: tabBar.preferredSize.height,
                          onPressed: () async {
                            if ((currentWorkType == WorksType.illust
                                        ? _tagsProvider.illustTags
                                        : _tagsProvider.novelTags)
                                    .isEmpty ||
                                flagNeedReRequest) {
                              // 列表为空的时候才会重新请求数据，否则使用旧的数据
                              requestBookmarkTags(currentWorkType, currentFilterModel.restrict);
                            }
                            _FilterModel? model = await BottomSheets.showCustomBottomSheet<_FilterModel>(
                              context: context,
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                              exitOnClickModal: false,
                              child: _buildFilterBottomSheet(buttonContext),
                            );
                            // 取消掉标签请求
                            _tagsCancelToken.cancel();
                            if (model != null) {
                              // 确定筛选后触发
                              changeFilter(currentWorkType, model);
                              (context as Element).markNeedsBuild();
                            }
                          },
                          child: Row(
                            children: [
                              Text(
                                  currentFilterModel.restrict == CONSTANTS.restrict_public
                                      ? LocalizationIntl.of(context).public
                                      : LocalizationIntl.of(context).private,
                                  style: const TextStyle(fontSize: 14)),
                              const Icon(Icons.filter_alt_outlined, size: 18),
                            ],
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ];
        },
        body: TabBarView(
          controller: _tabController,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            IllustGridTabPage(
              illustsProvider: illustsProvider,
              onRequest: (CancelToken cancelToken) async {
                return await ApiUser().getUserBookmarksIllust(
                  userId: widget.userId!,
                  restrict: illustFilterModel.restrict,
                  tag: illustFilterModel.tag,
                  cancelToken: cancelToken,
                );
              },
            ),
            NovelListTabPage(
              novelsProvider: novelsProvider,
              onRequest: (CancelToken cancelToken) async {
                return await ApiUser().getUserBookmarksNovel(
                  userId: widget.userId!,
                  restrict: novelFilterModel.restrict,
                  tag: novelFilterModel.tag,
                  cancelToken: cancelToken,
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  /// Filter筛选的底部弹窗
  Widget _buildFilterBottomSheet(BuildContext context) {
    _FilterModel cacheModel = currentFilterModel.copyWith();
    flagNeedReRequest = false;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      child: ChangeNotifierProvider.value(
        value: _tagsProvider,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const BottomSheetSlideBar(
              width: 48,
              padding: EdgeInsets.symmetric(vertical: 10),
            ),
            // 展示范围的选择
            Row(
              children: [
                const Expanded(
                  flex: 1,
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text("显示范围: ", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
                Builder(builder: (filterContext) {
                  return StatelessTextFlowFilter(
                    initialIndexes: {cacheModel.restrict == CONSTANTS.restrict_public ? 0 : 1},
                    unselectedBackground: Theme.of(context).colorScheme.background,
                    spacing: 4,
                    onTap: (int tapIndex) {
                      cacheModel.setRestrict(tapIndex == 0 ? CONSTANTS.restrict_public : CONSTANTS.restrict_private);
                      requestBookmarkTags(currentWorkType, cacheModel.restrict);
                      (filterContext as Element).markNeedsBuild();
                    },
                    texts: [
                      LocalizationIntl.of(context).public,
                      LocalizationIntl.of(context).private,
                    ],
                  );
                }),
              ],
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text("收藏的标签", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            // 标签列表
            ScrollConfiguration(
              behavior: _CusBehavior(),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height * 0.5,
                  maxHeight: MediaQuery.of(context).size.height * 0.5,
                ),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 4.0),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.background.withAlpha(150),
                    borderRadius: const BorderRadius.all(Radius.circular(8.0)),
                  ),
                  child: Consumer(
                    builder: ((context, BookmarkTagsProvider provider, child) {
                      switch (provider.loadingStatus) {
                        case LoadingStatus.loading:
                          return const RequestLoading();
                        case LoadingStatus.failed:
                          return RequestLoadingFailed(onRetry: () {
                            requestBookmarkTags(provider.currentWorksType, cacheModel.restrict);
                          });
                        case LoadingStatus.success:
                      }
                      List<BookmarkTag> tags =
                          provider.currentWorksType == WorksType.novel ? provider.novelTags : provider.illustTags;
                      return ListView.builder(
                        itemCount: tags.length + 1,
                        shrinkWrap: true,
                        itemBuilder: ((context, index) {
                          // 全部（默认选项）
                          if (index == 0) {
                            return _TagListItemWidget(
                              name: LocalizationIntl.of(context).all,
                              count: null,
                              isActived: cacheModel.tag == null,
                              onTap: () {
                                cacheModel.setTag(null);
                                (context as Element).markNeedsBuild();
                              },
                            );
                          }
                          // Tags
                          return _TagListItemWidget(
                            name: "#${tags[index - 1].name ?? 'unknown'}",
                            count: tags[index - 1].count ?? 0,
                            isActived: cacheModel.tag == tags[index - 1].name,
                            onTap: () {
                              cacheModel.setTag(tags[index - 1].name);
                              (context as Element).markNeedsBuild();
                            },
                          );
                        }),
                      );
                    }),
                  ),
                ),
              ),
            ),
            // 底部按钮
            SafeArea(
              child: Row(
                children: [
                  // 取消按钮
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8.0, bottom: 12, left: 0, right: 4),
                      child: CupertinoButton(
                        color: Theme.of(context).colorScheme.surfaceVariant,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        borderRadius: const BorderRadius.all(Radius.circular(8)),
                        onPressed: () {
                          if (cacheModel.restrict != currentFilterModel.restrict) flagNeedReRequest = true;
                          Navigator.of(context).pop<_FilterModel>(null);
                        },
                        child: Text(
                          LocalizationIntl.of(context).promptCancel,
                          style: TextStyle(fontSize: 14, color: Theme.of(context).colorScheme.primary),
                        ),
                      ),
                    ),
                  ),
                  // 确定按钮
                  Expanded(
                    flex: 1,
                    child: Padding(
                      padding: const EdgeInsets.only(top: 8.0, bottom: 12, left: 4, right: 0),
                      child: CupertinoButton(
                        color: Theme.of(context).colorScheme.primary,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        borderRadius: const BorderRadius.all(Radius.circular(8)),
                        onPressed: () {
                          Navigator.of(context).pop<_FilterModel>(cacheModel);
                          (context as Element).markNeedsBuild();
                        },
                        child: Text(
                          LocalizationIntl.of(context).promptConform,
                          style: TextStyle(fontSize: 14, color: Theme.of(context).colorScheme.onPrimary),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 获取收藏标签
  void requestBookmarkTags(WorksType worksType, String restrict) {
    assert(worksType == WorksType.illust || worksType == WorksType.novel);
    assert(restrict == CONSTANTS.restrict_public || restrict == CONSTANTS.restrict_private);
    _tagsProvider.seLoadStatus(LoadingStatus.loading);
    if (!_tagsCancelToken.isCancelled) _tagsCancelToken.cancel();
    _tagsCancelToken = CancelToken();
    switch (worksType) {
      case WorksType.illust:
        ApiUser().getBookmarkTags(WorksType.illust, restrict: restrict, cancelToken: _tagsCancelToken).then((value) {
          _tagsProvider.resetIllustTags(value.bookmarkTags ?? [], value.nextUrl);
          _tagsProvider.seLoadStatus(LoadingStatus.success);
        }).catchError((error) {
          if ((error as DioError).type == DioErrorType.cancel) return;
          _tagsProvider.seLoadStatus(LoadingStatus.failed);
        });
        break;
      case WorksType.novel:
      default:
        ApiUser().getBookmarkTags(WorksType.novel, restrict: restrict, cancelToken: _tagsCancelToken).then((value) {
          _tagsProvider.resetNovelTags(value.bookmarkTags ?? [], value.nextUrl);
          _tagsProvider.seLoadStatus(LoadingStatus.success);
        }).catchError((error) {
          if ((error as DioError).type == DioErrorType.cancel) return;
          _tagsProvider.seLoadStatus(LoadingStatus.failed);
        });
    }
  }

  /// 在筛选弹窗中点击确定后触发
  void changeFilter(WorksType worksType, _FilterModel model) {
    assert(worksType == WorksType.illust || worksType == WorksType.novel);
    if (!_cancelToken.isCancelled) _cancelToken.cancel();
    _cancelToken = CancelToken();
    switch (worksType) {
      case WorksType.illust:
        illustsProvider.setLoadingStatus(LoadingStatus.loading);
        illustFilterModel.update(model.restrict, model.tag);
        ApiUser()
            .getUserBookmarksIllust(
              userId: widget.userId!,
              restrict: model.restrict,
              tag: model.tag,
              cancelToken: _cancelToken,
            )
            .then((value) => illustsProvider.resetIllusts(value.illusts, value.nextUrl))
            .catchError((error) {
          if ((error as DioError).type == DioErrorType.cancel) return;
          illustsProvider.setLoadingStatus(LoadingStatus.failed);
        });
        break;
      case WorksType.novel:
      default:
        novelsProvider.setLoadingStatus(LoadingStatus.loading);
        novelFilterModel.update(model.restrict, model.tag);
        ApiUser()
            .getUserBookmarksNovel(
              userId: widget.userId!,
              restrict: model.restrict,
              tag: model.tag,
              cancelToken: _cancelToken,
            )
            .then((value) => novelsProvider.resetNovels(value.novels, value.nextUrl))
            .catchError((error) {
          if ((error as DioError).type == DioErrorType.cancel) return;
          novelsProvider.setLoadingStatus(LoadingStatus.failed);
        });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    if (!_cancelToken.isCancelled) _cancelToken.cancel();
    if (!_tagsCancelToken.isCancelled) _cancelToken.cancel();
    _tagsProvider.dispose();
    super.dispose();
  }
}

/// 去除Android设备滚动到边界后的动画效果
class _CusBehavior extends ScrollBehavior {
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) {
    if (Platform.isAndroid || Platform.isFuchsia) return child;
    return super.buildOverscrollIndicator(context, child, details);
  }
}

/// 用于传输筛选条件（插画漫画与小说可以通用）
class _FilterModel {
  String restrict;

  /// 为null时为不根据tag筛选
  String? tag;

  _FilterModel(this.restrict, this.tag);

  _FilterModel copyWith() {
    return _FilterModel(restrict, tag);
  }

  void update(String restrict, String? tag) {
    this.restrict = restrict;
    this.tag = tag;
  }

  void setRestrict(String restrict) {
    this.restrict = restrict;
  }

  void setTag(String? tag) {
    this.tag = tag;
  }
}

class _TagListItemWidget extends StatelessWidget {
  final String name;
  final int? count;
  final bool isActived;
  final void Function() onTap;

  const _TagListItemWidget({
    required this.name,
    required this.count,
    required this.isActived,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.all(Radius.circular(8.0)),
      child: Material(
        shadowColor: Colors.transparent,
        color: isActived ? Theme.of(context).colorScheme.primaryContainer : Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.all(Radius.circular(8.0)),
              border: Border.all(color: isActived ? Theme.of(context).colorScheme.primary : Colors.transparent),
            ),
            child: Text(
              name,
              style: TextStyle(
                fontSize: 16,
                color: isActived
                    ? Theme.of(context).colorScheme.onPrimaryContainer
                    : Theme.of(context).colorScheme.onSurface,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ),
    );
  }
}
